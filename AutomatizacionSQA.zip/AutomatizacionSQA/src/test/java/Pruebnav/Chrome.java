package Pruebnav;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.awt.*;
import java.util.concurrent.TimeUnit;

public class Chrome {
    private WebDriver driver;

    public void setUp() throws Exception {
        System.setProperty("web-driver.chrome.driver", "./src/test/resources/Drivercrome/chrome.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://sanangel.com.co/");
    }

    public void testGooglePage() {
        driver.findElement(By.xpath("//*[@id=\"destacados-tab\"]/div[2]/div/ul/li[1]/a/img")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.findElement(By.xpath("//*[@id=\"quantity_6705a9960043d\"]")).click();
        driver.findElement(By.xpath("//*[@id=\"quantity_6705a9960043d\"]")).click();
        driver.findElement(By.className("single_add_to_cart_button button alt")).click();
        driver.findElement(By.xpath("//*[@id=\"sticky-wrapper\"]/header/div[2]/div/a/img")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.findElement(By.xpath("//*[@id=\"destacados-tab\"]/div[2]/div/ul/li[3]/a[2]/img")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        for (int i = 0; i <= 4; i++) {
            driver.findElement(By.xpath("//*[@id=\"quantity_6705a931ca770\"]")).click();
            driver.findElement(By.className("single_add_to_cart_button button alt")).click();
        }
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    }
    public void tearDown() {
        //driver.quit();
    }
}
